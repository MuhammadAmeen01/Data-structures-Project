#include "project.h"
int main()
{
	project obj;
	obj.menu();
}
